本项目为 **JustAuth开源项目**（[gitee](https://gitee.com/yadong.zhang/JustAuth) | [github](https://github.com/justauth/JustAuth)）的demo。

![](doc/media/660728a0.png)

![](doc/media/2d3990f5.png)

# 交流

|  微信(备注:加群)  |  公众号  |
| :------------: | :------------: |
| <img src="https://gitee.com/yadong.zhang/static/raw/master/wx/wx.png" width="170"/> | <img src="https://gitee.com/yadong.zhang/static/raw/master/wx/wechat_account.jpg" width="200" /> |

 **QQ群** 
 
- JustAuth交流群 （230017570）：专业交流该项目

- 开源总群 （190886500）：各个开源项目的都有，也有博客建设等方面的朋友。

